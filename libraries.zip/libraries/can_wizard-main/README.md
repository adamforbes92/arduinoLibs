TODO:
- code refactoring
- test dumb mode
- fix prompt flickering with some commands
- add standard ID filtering to cansmartfilter

An article about the project:
- in [Russian](https://habr.com/ru/articles/793326/).
- in [English](https://okhsunrog.ru/articles/2024/02/15/can_bus_sniffer/).
