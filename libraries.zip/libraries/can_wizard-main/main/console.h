#ifndef MAIN_CONSOLE_TASK_H
#define MAIN_CONSOLE_TASK_H

// functions

void console_task_tx(void* arg);
void console_task_interactive(void* arg);
void initialize_console(void);

#endif // MAIN_CONSOLE_TASK_H
