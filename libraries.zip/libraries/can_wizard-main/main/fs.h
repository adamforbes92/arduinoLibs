#ifndef MAIN_FS_H
#define MAIN_FS_H

#define MOUNT_PATH   "/data"
#define HISTORY_PATH MOUNT_PATH "/history.txt"

// functions

void initialize_filesystem(void);

#endif // MAIN_FS_H
