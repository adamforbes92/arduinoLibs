#ifndef MAIN_CMD_SYSTEM_H
#define MAIN_CMD_SYSTEM_H

void register_system(void);

#endif // MAIN_CMD_SYSTEM_H
