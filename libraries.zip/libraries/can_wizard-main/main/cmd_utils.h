#ifndef MAIN_CMD_UTILS_H
#define MAIN_CMD_UTILS_H

// functions

void register_utils_commands(void);

#endif // MAIN_CMD_UTILS_H
